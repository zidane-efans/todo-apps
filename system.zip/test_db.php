<?php
$mysqli = new mysqli("localhost", "root", "root", "taskflow");
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}
$result = $mysqli->query("DESCRIBE projects");
while ($row = $result->fetch_assoc()) {
    print_r($row);
}
echo "\n\n";
$result = $mysqli->query("DESCRIBE tasks");
while ($row = $result->fetch_assoc()) {
    print_r($row);
}
